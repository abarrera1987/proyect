-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 12-11-2018 a las 12:10:04
-- Versión del servidor: 5.7.21
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proceso`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conf_headquarters`
--

DROP TABLE IF EXISTS `conf_headquarters`;
CREATE TABLE IF NOT EXISTS `conf_headquarters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL DEFAULT '-',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `conf_headquarters`
--

INSERT INTO `conf_headquarters` (`id`, `name`) VALUES
(1, 'Bogotá'),
(2, 'México'),
(3, 'Perú');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conf_process`
--

DROP TABLE IF EXISTS `conf_process`;
CREATE TABLE IF NOT EXISTS `conf_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_number` varchar(11) NOT NULL,
  `description` varchar(200) NOT NULL DEFAULT '-',
  `id_headquarters` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `budget` varchar(250) NOT NULL,
  `state` varchar(10) NOT NULL DEFAULT 'inactive',
  PRIMARY KEY (`id`),
  UNIQUE KEY `process_number` (`process_number`),
  KEY `id_headquarters` (`id_headquarters`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `conf_process`
--

INSERT INTO `conf_process` (`id`, `process_number`, `description`, `id_headquarters`, `create_date`, `budget`, `state`) VALUES
(1, '00000001', 'Prueba', 1, '2018-11-11', '3000', 'active'),
(2, '00000002', 'Prueba 2', 2, '2018-11-11', '6000', 'active'),
(7, '00000007', 'color', 1, '2018-11-11', '15000', 'active'),
(9, '00000009', 'asdasdas', 1, '2018-11-11', '234234', 'active'),
(10, '00000010', 'holi', 1, '2018-11-11', '23543534534', 'active'),
(11, '00000011', 'Prueba', 1, '2018-11-11', '214234234', 'active'),
(12, '00000012', '524324234', 1, '2018-11-11', '23342342', 'active'),
(13, '00000013', 'p', 1, '2018-11-11', '23234324', 'active'),
(14, '00000014', 'Pruebas update', 2, '2018-11-11', '150000', 'active'),
(17, '00000017', 'Prueba perú', 3, '2018-11-11', '150000', 'active'),
(18, '00000018', 'Descripción', 3, '2018-11-11', '125555', 'active');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usu_users`
--

DROP TABLE IF EXISTS `usu_users`;
CREATE TABLE IF NOT EXISTS `usu_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL DEFAULT '-',
  `email` varchar(250) NOT NULL DEFAULT '-',
  `password` varchar(250) NOT NULL DEFAULT '-',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usu_users`
--

INSERT INTO `usu_users` (`id`, `name`, `email`, `password`) VALUES
(1, 'Alexander escobar', 'alex_1128@hotmail.es', '40bd001563085fc35165329ea1ff5c5ecbdbbeef');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `conf_process`
--
ALTER TABLE `conf_process`
  ADD CONSTRAINT `fk_process_headquarters` FOREIGN KEY (`id_headquarters`) REFERENCES `conf_headquarters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
